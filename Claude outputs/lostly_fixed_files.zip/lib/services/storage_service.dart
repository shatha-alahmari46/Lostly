import 'dart:io';

import 'package:firebase_core/firebase_core.dart' show FirebaseException;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

/// Thrown when the picked image file no longer exists on the device.
class LocalImageMissingException implements Exception {
  const LocalImageMissingException(this.path);

  final String path;

  @override
  String toString() => 'LocalImageMissingException: $path';
}

class StorageService {
  StorageService._();

  static final StorageService instance = StorageService._();

  FirebaseStorage get _storage => FirebaseStorage.instance;

  // =========================================================
  // UPLOAD POST IMAGE
  // =========================================================

  /// Uploads [image] to `post_images/{userId}/{timestamp}.{ext}` and returns
  /// the download URL of the uploaded object.
  ///
  /// The download URL is requested from the reference returned by the
  /// completed upload task, so it always points at the object that was
  /// actually written.
  Future<String> uploadPostImage({
    required String userId,
    required XFile image,
  }) async {
    final file = File(image.path);

    if (!await file.exists()) {
      throw LocalImageMissingException(image.path);
    }

    final extension = _extensionOf(image.name.isNotEmpty ? image.name : image.path);

    // Only safe characters in the object name (no spaces, colons, etc.).
    final fileName = '${DateTime.now().millisecondsSinceEpoch}.$extension';

    final ref = _storage.ref().child('post_images').child(userId).child(fileName);

    debugPrint('[Storage] Uploading ${file.path} -> ${ref.fullPath} '
        '(bucket: ${ref.bucket})');

    final TaskSnapshot snapshot = await ref.putFile(
      file,
      SettableMetadata(contentType: _contentTypeFor(extension)),
    );

    if (snapshot.state != TaskState.success) {
      throw FirebaseException(
        plugin: 'firebase_storage',
        code: 'upload-not-completed',
        message: 'Upload finished with state ${snapshot.state}.',
      );
    }

    final downloadUrl = await snapshot.ref.getDownloadURL();

    debugPrint('[Storage] Upload complete: $downloadUrl');

    return downloadUrl;
  }

  // =========================================================
  // DELETE IMAGE (best effort)
  // =========================================================

  /// Deletes an image previously uploaded to Firebase Storage.
  /// Never throws: a missing object or a non-Firebase URL is ignored.
  Future<void> deleteImageByUrl(String imageUrl) async {
    if (!_isFirebaseStorageUrl(imageUrl)) return;

    try {
      await _storage.refFromURL(imageUrl).delete();
      debugPrint('[Storage] Deleted $imageUrl');
    } on FirebaseException catch (e) {
      // object-not-found simply means it is already gone.
      debugPrint('[Storage] Could not delete image (${e.code}): ${e.message}');
    } catch (e) {
      debugPrint('[Storage] Could not delete image: $e');
    }
  }

  // =========================================================
  // HELPERS
  // =========================================================

  bool _isFirebaseStorageUrl(String url) {
    return url.startsWith('gs://') ||
        url.startsWith('https://firebasestorage.googleapis.com/') ||
        url.contains('.firebasestorage.app/');
  }

  String _extensionOf(String name) {
    final dot = name.lastIndexOf('.');

    if (dot == -1 || dot == name.length - 1) return 'jpg';

    final ext = name.substring(dot + 1).toLowerCase();

    const allowed = {'jpg', 'jpeg', 'png', 'webp', 'gif', 'heic', 'heif'};

    return allowed.contains(ext) ? ext : 'jpg';
  }

  String _contentTypeFor(String extension) {
    switch (extension) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      case 'heic':
        return 'image/heic';
      case 'heif':
        return 'image/heif';
      default:
        return 'image/jpeg';
    }
  }
}
